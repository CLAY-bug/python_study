# 作者: 王道 龙哥
# 2022年06月09日09时50分21秒

def receive():
    return 'I am receive'