# 作者: 王道 龙哥
# 2022年06月09日09时50分14秒

def send():
    print('I am send')