# 作者 ： 赖鑫
# 2022年06月13日19时37分52秒

def send():
    print("i am send")
