# 作者 ： 赖鑫
# 2022年06月13日19时38分21秒

def reveice():
    print("i amd receive")
